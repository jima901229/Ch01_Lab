#include<stdio.h>
typedef struct _sperson
{
	char name[8];
	int gender;
	int age;
}Person;


