﻿#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int i, a, b;
	unsigned long c = 1;
	printf("請輸入底數:");
	scanf_s("%d", &a);
	printf("請輸入指數");
	scanf_s("%d", &b);
	for (i = 1; i <= b; i++)
	{
		c *= a;
	}
	printf("%lu", c);
	return 0;
}