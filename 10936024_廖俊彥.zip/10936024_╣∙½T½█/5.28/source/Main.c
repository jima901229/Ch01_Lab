#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int i;
	char input;
	printf("�п�J�@�Ӥj�g�^��r\n");
	for (i = 0; i < 50; i++) {
	
		scanf_s("%c", &input);

		switch (input) {
		case'A':
			printf("a");
			break;
		case'B':
			printf("b");
			break;
		case'C':
			printf("c");
			break;
		case'D':
			printf("d");
			break;
		case'E':
			printf("e");
			break;
		case'F':
			printf("f");
			break;
		case'G':
			printf("g");
			break;
		case'H':
			printf("h");
			break;
		case'I':
			printf("i");
			break;
		case'J':
			printf("j");
			break;
		case'K':
			printf("k");
			break;
		case'L':
			printf("l");
			break;
		case'M':
			printf("m");
			break;
		case'N':
			printf("n");
			break;
		case'O':
			printf("o");
			break;
		case'P':
			printf("p");
			break;
		case'Q':
			printf("q");
			break;
		case'R':
			printf("r");
			break;
		case'S':
			printf("s");
			break;
		case'T':
			printf("t");
			break;
		case'U':
			printf("u");
			break;
		case'V':
			printf("v");
			break;
		case'X':
			printf("x");
			break;
		case'Y':
			printf("y");
			break;
		case'Z':
			printf("z");
			break;
		default:
				break;
		
		}
		printf("\n");
	}


	system("pause");
	return 0;
}